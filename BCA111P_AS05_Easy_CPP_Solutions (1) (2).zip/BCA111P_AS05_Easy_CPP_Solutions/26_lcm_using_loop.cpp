#include <iostream>
using namespace std;

int main() {
    int a, b;
    cout << "Enter two positive integers: ";
    cin >> a >> b;

    if (a <= 0 || b <= 0) {
        cout << "Please enter positive integers.\n";
        return 0;
    }

    int candidate = (a > b) ? a : b;
    while (candidate % a != 0 || candidate % b != 0) candidate++;

    cout << "LCM = " << candidate << endl;
    return 0;
}
