#include <iostream>
using namespace std;

int main() {
    for (int n = 1; n <= 100; n++) {
        int temp = n, digitSum = 0;
        while (temp > 0) {
            digitSum += temp % 10;
            temp /= 10;
        }
        if (digitSum != 0 && n % digitSum == 0) cout << n << " ";
    }
    cout << endl;
    return 0;
}
