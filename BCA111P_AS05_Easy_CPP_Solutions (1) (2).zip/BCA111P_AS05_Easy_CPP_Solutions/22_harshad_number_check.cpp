#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter a positive number: ";
    cin >> n;

    int temp = n, digitSum = 0;
    while (temp > 0) {
        digitSum += temp % 10;
        temp /= 10;
    }

    if (n > 0 && n % digitSum == 0) cout << n << " is a Harshad number.\n";
    else cout << n << " is not a Harshad number.\n";
    return 0;
}
