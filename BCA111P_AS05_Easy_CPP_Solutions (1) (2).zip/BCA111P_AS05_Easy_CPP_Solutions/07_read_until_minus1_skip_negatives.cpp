#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter numbers (-1 to stop):\n";

    while (true) {
        cin >> n;
        if (n == -1) break;
        if (n < 0) continue; // Ignore other negative numbers
        cout << "Accepted: " << n << endl;
    }
    return 0;
}
