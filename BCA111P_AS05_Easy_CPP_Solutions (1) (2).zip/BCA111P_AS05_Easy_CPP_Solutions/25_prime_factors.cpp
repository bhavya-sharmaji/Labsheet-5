#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter an integer greater than 1: ";
    cin >> n;

    if (n <= 1) {
        cout << "Please enter a number greater than 1.\n";
        return 0;
    }

    cout << "Prime factors: ";
    for (int divisor = 2; divisor <= n; divisor++) {
        while (n % divisor == 0) {
            cout << divisor << " ";
            n /= divisor;
        }
    }
    cout << endl;
    return 0;
}
