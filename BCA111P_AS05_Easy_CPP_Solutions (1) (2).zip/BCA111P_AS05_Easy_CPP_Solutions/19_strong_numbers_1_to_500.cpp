#include <iostream>
using namespace std;

int main() {
    for (int n = 1; n <= 500; n++) {
        int temp = n, sum = 0;
        do {
            int digit = temp % 10, factorial = 1;
            for (int i = 1; i <= digit; i++) factorial *= i;
            sum += factorial;
            temp /= 10;
        } while (temp != 0);

        if (sum == n) cout << n << " ";
    }
    cout << endl;
    return 0;
}
