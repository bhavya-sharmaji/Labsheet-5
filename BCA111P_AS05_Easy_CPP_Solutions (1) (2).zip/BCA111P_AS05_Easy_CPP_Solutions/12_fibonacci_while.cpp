#include <iostream>
using namespace std;

int main() {
    int terms;
    cout << "How many Fibonacci terms? ";
    cin >> terms;

    if (terms <= 0) {
        cout << "Enter a positive number.\n";
        return 0;
    }

    long long a = 0, b = 1;
    int count = 0;
    while (count < terms) {
        cout << a << " ";
        long long next = a + b;
        a = b;
        b = next;
        count++;
    }
    cout << endl;
    return 0;
}
