#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter a non-negative integer: ";
    cin >> n;

    if (n < 0) {
        cout << "Please enter a non-negative integer.\n";
        return 0;
    }

    int original = n, temp = n, reverse = 0;
    do {
        reverse = reverse * 10 + temp % 10;
        temp /= 10;
    } while (temp != 0);

    cout << "Reverse = " << reverse << endl;
    if (reverse == original) cout << "It is a palindrome.\n";
    else cout << "It is not a palindrome.\n";
    return 0;
}
