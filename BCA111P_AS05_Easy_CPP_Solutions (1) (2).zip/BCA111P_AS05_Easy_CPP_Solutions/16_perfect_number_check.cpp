#include <iostream>
using namespace std;

int main() {
    int n, sum = 0;
    cout << "Enter a positive number: ";
    cin >> n;

    for (int i = 1; i <= n / 2; i++) {
        if (n % i == 0) sum += i;
    }

    if (n > 1 && sum == n) cout << n << " is a perfect number.\n";
    else cout << n << " is not a perfect number.\n";
    return 0;
}
