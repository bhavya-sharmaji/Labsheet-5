#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter a number: ";
    cin >> n;

    bool prime = (n >= 2);
    for (int i = 2; i * i <= n && prime; i++) {
        if (n % i == 0) {
            prime = false;
            break; // No need to check further
        }
    }

    if (prime) cout << n << " is prime.\n";
    else cout << n << " is not prime.\n";
    return 0;
}
