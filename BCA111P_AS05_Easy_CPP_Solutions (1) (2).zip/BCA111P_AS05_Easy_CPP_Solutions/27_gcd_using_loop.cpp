#include <iostream>
using namespace std;

int main() {
    int a, b;
    cout << "Enter two non-negative integers: ";
    cin >> a >> b;

    if (a < 0 || b < 0) {
        cout << "Please enter non-negative integers.\n";
        return 0;
    }

    int smaller = (a < b) ? a : b;
    int gcd = 1;

    if (a == 0) gcd = b;
    else if (b == 0) gcd = a;
    else {
        for (int i = 1; i <= smaller; i++) {
            if (a % i == 0 && b % i == 0) gcd = i;
        }
    }

    cout << "GCD = " << gcd << endl;
    return 0;
}
