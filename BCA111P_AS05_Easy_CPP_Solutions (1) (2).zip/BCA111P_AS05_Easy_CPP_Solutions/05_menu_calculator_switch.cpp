#include <iostream>
using namespace std;

int main() {
    double a, b;
    char op;
    cout << "Enter first number, operator (+ - * /), second number: ";
    cin >> a >> op >> b;

    switch (op) {
        case '+': cout << "Result = " << a + b; break;
        case '-': cout << "Result = " << a - b; break;
        case '*': cout << "Result = " << a * b; break;
        case '/':
            if (b == 0) cout << "Cannot divide by zero.";
            else cout << "Result = " << a / b;
            break;
        default: cout << "Invalid operator.";
    }
    cout << endl;
    return 0;
}
