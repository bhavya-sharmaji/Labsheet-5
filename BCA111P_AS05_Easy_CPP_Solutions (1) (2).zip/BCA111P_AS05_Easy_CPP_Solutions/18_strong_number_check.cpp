#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter a non-negative integer: ";
    cin >> n;

    if (n < 0) {
        cout << "Negative numbers are not strong numbers here.\n";
        return 0;
    }

    int original = n, temp = n, sum = 0;
    do {
        int digit = temp % 10;
        int factorial = 1;
        for (int i = 1; i <= digit; i++) factorial *= i;
        sum += factorial;
        temp /= 10;
    } while (temp != 0);

    if (sum == original) cout << original << " is a strong number.\n";
    else cout << original << " is not a strong number.\n";
    return 0;
}
