#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter a non-negative integer: ";
    cin >> n;

    if (n < 0) n = -n;
    int evenSum = 0, oddSum = 0;

    do {
        int digit = n % 10;
        if (digit % 2 == 0) evenSum += digit;
        else oddSum += digit;
        n /= 10;
    } while (n != 0);

    cout << "Sum of even digits = " << evenSum << endl;
    cout << "Sum of odd digits = " << oddSum << endl;
    return 0;
}
