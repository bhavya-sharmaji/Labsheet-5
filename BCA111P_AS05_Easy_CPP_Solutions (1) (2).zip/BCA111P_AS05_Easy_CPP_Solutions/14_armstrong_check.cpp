#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter a non-negative integer: ";
    cin >> n;

    if (n < 0) {
        cout << "Negative numbers are not Armstrong numbers here.\n";
        return 0;
    }

    int original = n, temp = n, digits = 0;
    do {
        digits++;
        temp /= 10;
    } while (temp != 0);

    temp = n;
    long long sum = 0;
    do {
        int digit = temp % 10;
        long long power = 1;
        for (int i = 0; i < digits; i++) power *= digit;
        sum += power;
        temp /= 10;
    } while (temp != 0);

    if (sum == original) cout << original << " is an Armstrong number.\n";
    else cout << original << " is not an Armstrong number.\n";
    return 0;
}
