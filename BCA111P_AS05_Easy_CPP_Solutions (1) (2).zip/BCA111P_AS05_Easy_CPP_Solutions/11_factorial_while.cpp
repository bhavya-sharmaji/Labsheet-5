#include <iostream>
using namespace std;

int main() {
    int n;
    unsigned long long factorial = 1;
    cout << "Enter a number (0 to 20): ";
    cin >> n;

    if (n < 0 || n > 20) {
        cout << "Please enter a number from 0 to 20.\n";
        return 0;
    }

    int i = 1;
    while (i <= n) {
        factorial *= i;
        i++;
    }
    cout << "Factorial = " << factorial << endl;
    return 0;
}
