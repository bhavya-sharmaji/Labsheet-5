#include <iostream>
using namespace std;

int main() {
    int choice;
    cout << "Choose 1, 2, or 3: ";
    cin >> choice;

    switch (choice) {
        case 1: cout << "You chose One.\n"; break;
        case 2: cout << "You chose Two.\n"; break;
        case 3: cout << "You chose Three.\n"; break;
        default: cout << "No matching choice.\n";
    }
    return 0;
}
